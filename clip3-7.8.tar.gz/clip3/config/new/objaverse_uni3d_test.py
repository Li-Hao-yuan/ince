name = 'objaverse_uni3d_test'
work_dir = 'work_dirs/' + name

using_channel = 14
load_features = True
sigclip_loss = True
clip_type = "laion_H"

train_cfg = dict(
    epoch=30,
    fp16=False,
)

test_cfg = dict(
    test_gt=False,
    val_interval=5,# 10

    dataset="abo",
    task="classification",
    test_interval=5,
)

model_cfg = dict(
    clip_model=clip_type,
    pointnet_model="uni3D",
    sigclip_loss=sigclip_loss,
    model_setting=dict(
        load_features=load_features,

        pc_model="eva02_small_patch14_224",
        pretrained_pc=None,
        drop_path_rate=0.2,

        pc_feat_dim=384,
        embed_dim=1024,
        group_size=64,
        num_group=512,
        output_dim=1024,
        pc_encoder_dim=512,
        patch_dropout=0.5,
        in_channel=6,

        model_type="parallel",
        load_rgb=False,
        load_pretrained=True,
        ckpt_path="/data1/lihaoyuan/clip3D/clip3/cache/uni3D/uni3d-S.pt",
    ),
    learning_rate=1e-4, # single GPU
    pts_channel=using_channel,
    forward_all=True,
    loss_weight=dict(
        text_weight=0.5,
        image_weight=0.5,
        buffer_loss=False,
        sigclip_loss=sigclip_loss
    ),
    save_interval = 15,
)

log_cfg = dict(
    skip_tqdm=True,
    print_interval=50,
)

data_cfg = dict(
    dataset=dict(
        type="objaverse",
        data_dir="/data1/lihaoyuan/clip3D/gaussian-splatting/clip3/objaverse_all",
        using_channel=using_channel,
        load_features=load_features,
        load_npy=True,
        augment=False,
        trun_uni3d=False,
        clip_type=clip_type,
        data_split="sample_abo_all.json",
    ),
    batch_size=24,
    test_batch_size=32,
    pin_memory=False,
    nw=4,
)

use_ddp_wrapper = True
find_unused_parameters = True
