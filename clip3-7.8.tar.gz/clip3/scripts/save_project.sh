mkdir /data1/lihaoyuan/clip3
cp -r /data1/lihaoyuan/clip3D/clip3/lib /data1/lihaoyuan/clip3/lib
cp -r /data1/lihaoyuan/clip3D/clip3/config /data1/lihaoyuan/clip3/config
cp -r /data1/lihaoyuan/clip3D/clip3/scripts /data1/lihaoyuan/clip3/scripts
cp /data1/lihaoyuan/clip3D/clip3/*.py /data1/lihaoyuan/clip3/
cp /data1/lihaoyuan/clip3D/clip3/*.txt /data1/lihaoyuan/clip3/
cd /data1/lihaoyuan
tar -zcf clip3.tar.gz clip3
rm -r /data1/lihaoyuan/clip3