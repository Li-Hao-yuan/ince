# dataset
from SUN_dataset import SUN
from Objaverse_dataset import Objaverse

# model
from get_model import CLIP3, CLIP3_loss

