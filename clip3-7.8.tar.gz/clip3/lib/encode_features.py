import os
import clip
import torch
import open_clip
from tqdm import tqdm
import numpy as np

from SUN_dataset import SUN
from ABO_dataset import ABO
from Mvimgnet_dataset import Mvimgnet
from Objaverse_dataset import Objaverse
from torch.utils.data import DataLoader
from PIL import Image

import argparse

# python /data1/lihaoyuan/clip3D/clip3/lib/encode_features.py --gpu 2 --clip_type laion_G

torch.backends.cudnn.benchmark = True
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:128"

def parse_args():
    parser = argparse.ArgumentParser(description='Train a GAN model')
    parser.add_argument('--gpu', type=str, default="0")
    parser.add_argument('--clip-type', '--clip_type', type=str, default="clip")
    args = parser.parse_args()
    return args

# ps -xH | grep encoded_features | awk '{print $1}' | xargs kill -9
## python /data1/lihaoyuan/clip3D/clip3/lib/encode_features.py > "/data1/lihaoyuan/clip3D/clip3/data/features/laion_bigG_objaverse.log" 2>&1 &
## python /data1/lihaoyuan/clip3D/clip3/lib/encode_features.py > "/data1/lihaoyuan/clip3D/clip3/data/features/laion_g_objaverse.log" 2>&1 &
## python /data1/lihaoyuan/clip3D/clip3/lib/encode_features.py > "/data1/lihaoyuan/clip3D/clip3/data/features/laion_h_objaverse.log" 2>&1 &

## python /data1/lihaoyuan/clip3D/clip3/lib/encode_features.py > "/data1/lihaoyuan/clip3D/clip3/data/features/eva_enormous_internlm.log" 2>&1 &

## make model
args = parse_args()
device = "cuda:"+args.gpu
clip_type = args.clip_type #"laion_bigG"
assert clip_type in ["clip", 
                     "eva_base", "eva_large", "eva_enormous", 
                     "laion_G", "laion_H", "laion_bigG"]

batch_size = 8
if clip_type == "clip":
    clip_model, preprocessor = clip.load("/data1/lihaoyuan/clip3D/clip3/cache/clip/ViT-B-16.pt", device=device)
else:
    clip_model_dict = {
        "eva_base": ["/data1/lihaoyuan/clip3D/clip3/cache/eva02_base_patch16_clip_224.merged2b_s8b_b131k/open_clip_pytorch_model.bin", "EVA02-B-16"],
        "eva_large": ["/data1/lihaoyuan/clip3D/clip3/cache/eva02_large_patch14_clip_224.merged2b_s4b_b131k/open_clip_pytorch_model.bin", "EVA02-L-14"],
        "eva_enormous": ["/data1/lihaoyuan/clip3D/clip3/cache/eva02_enormous_patch14_plus_clip_224.laion2b_s9b_b144k/open_clip_pytorch_model.bin", "EVA02-E-14-plus"],
        "laion_G": ["/data1/lihaoyuan/clip3D/clip3/cache/laion/CLIP-ViT-g-14-laion2B-s34B-b88K/pytorch_model.bin", "ViT-g-14"],
        "laion_H": ["/data1/lihaoyuan/clip3D/clip3/cache/laion/CLIP-ViT-H-14-laion2B-s32B-b79K/pytorch_model.bin", "ViT-H-14"],
        "laion_bigG": ["/data1/lihaoyuan/clip3D/clip3/cache/laion/CLIP-ViT-bigG-14-laion2B-39B-b160k/pytorch_model.bin", "ViT-bigG-14"],
    }
    clip_model_path, model_name = clip_model_dict[clip_type]
    clip_model, preprocessor, _ = open_clip.create_model_and_transforms(model_name=model_name, pretrained=clip_model_path) 
    clip_model.to(device)

save_root = "/data1/lihaoyuan/clip3D/clip3/data/features"
save_root = os.path.join(save_root, clip_type)
os.makedirs(save_root, exist_ok=True)

## choose datasets
def build_dataset(data_type, data_dir):
    using_channel=14
    data_split = "sample_all.json"
    refine_label = True
    load_blip2 = False

    if data_type == "sun":
        train_dataset = SUN(data_dir, using_channel=using_channel, data_split=data_split, refine_label=refine_label, shuffle=False, preprocess_image=False)
        test_dataset = SUN(data_dir, is_train=False, using_channel=using_channel, data_split=data_split, refine_label=refine_label)
        return train_dataset, test_dataset
    elif data_type == "objaverse":
        train_dataset = Objaverse(data_dir, using_channel=using_channel, data_split=data_split, refine_label=refine_label, load_blip2=load_blip2, shuffle=False, preprocess_image=False)
        test_dataset = Objaverse(data_dir, is_train=False, using_channel=using_channel, data_split=data_split, refine_label=refine_label)
        return train_dataset, test_dataset
    elif data_type == "abo":
        train_dataset = ABO(data_dir, using_channel=using_channel, data_split=data_split, shuffle=False, preprocess_image=False)
        test_dataset = ABO(data_dir, is_train=False, using_channel=using_channel, data_split=data_split)
        return train_dataset, test_dataset
    elif data_type == "mvimgnet":
        train_dataset = Mvimgnet(data_dir, using_channel=using_channel, data_split=data_split, shuffle=False, preprocess_image=False)
        test_dataset = Mvimgnet(data_dir, is_train=False, using_channel=using_channel, data_split=data_split)
        return train_dataset, test_dataset
    else:
        raise 

data_root = "/data1/lihaoyuan/clip3D/gaussian-splatting/clip3"
data_type = "objaverse"
assert data_type in ["ABO", "objaverse_all", "sunrgbd_all", "mvimgnet", "objaverse"]
data_type_dict = {
    "ABO":"abo", "objaverse_all":"objaverse", "sunrgbd_all":"sun", "mvimgnet":"mvimgnet", "objaverse":"objaverse"
}

train_dataset, test_dataset = build_dataset(data_type_dict[data_type], os.path.join(data_root, data_type))
train_dataset.file_paths.extend(test_dataset.file_paths)
data_loader = DataLoader(train_dataset, batch_size, num_workers=4, shuffle=False)

## collect features
text_type = "original"
# text_type = "internlm"

save_dataset_root = os.path.join(save_root, data_type)
save_text_root = os.path.join(save_dataset_root, "text_features", text_type)
save_image_root = os.path.join(save_dataset_root, "image_features")

os.makedirs(save_text_root, exist_ok=True)
os.makedirs(save_image_root, exist_ok=True)

clip_model.eval()
with torch.no_grad():
    for meta_data in tqdm(data_loader):
        skip_flag = True
        for item_path in meta_data["item_path"]:
            item_subfix = item_path.split("objects/")[1].split(".")[0]+".npy"
            if not os.path.exists(os.path.join(save_text_root, item_subfix)) or not os.path.exists(os.path.join(save_image_root, item_subfix)):
                skip_flag = False
                break
        if skip_flag: continue

        # text
        text = meta_data["text"]

        if clip_type == "clip": text = clip.tokenize(text).to(device)
        else: text = open_clip.tokenize(text).to(device)
        text_features = clip_model.encode_text(text).to(torch.float32)

        # image
        image_list = []
        images = meta_data["image"].cpu().data.numpy()
        for image in images:
            image_list.append(preprocessor(Image.fromarray(image)).unsqueeze(0))
        image = torch.cat(image_list).to(device)
        image_features = clip_model.encode_image(image).to(torch.float32)

        for item_path, text_feature, image_feature in \
            zip(meta_data["item_path"], text_features, image_features):

            item_subfix = item_path.split("objects/")[1].split(".")[0]+".npy"
            
            if "/" in item_subfix:
                folder_anme = item_subfix.split("/")[0]
                os.makedirs(os.path.join(save_text_root, folder_anme), exist_ok=True)
                os.makedirs(os.path.join(save_image_root, folder_anme), exist_ok=True)
            
            if not os.path.exists(os.path.join(save_text_root, item_subfix)):
                np.save(os.path.join(save_text_root, item_subfix), text_feature.cpu().data.numpy())
            if not os.path.exists(os.path.join(save_image_root, item_subfix)):
                np.save(os.path.join(save_image_root, item_subfix), image_feature.cpu().data.numpy())
        
        del text_features, image_features
        torch.cuda.empty_cache()
            
