import os
import json
import torch
import random
import numpy as np
from PIL import Image
from torch.utils.data import Dataset
import torchvision
    

def build_rotation(r):
    norm = np.sqrt(r[:,0]*r[:,0] + r[:,1]*r[:,1] + r[:,2]*r[:,2] + r[:,3]*r[:,3])

    q = r / norm[:, None]

    R = np.zeros((q.shape[0], 3, 3))

    r = q[:, 0]
    x = q[:, 1]
    y = q[:, 2]
    z = q[:, 3]

    R[:, 0, 0] = 1 - 2 * (y*y + z*z)
    R[:, 0, 1] = 2 * (x*y - r*z)
    R[:, 0, 2] = 2 * (x*z + r*y)
    R[:, 1, 0] = 2 * (x*y + r*z)
    R[:, 1, 1] = 1 - 2 * (x*x + z*z)
    R[:, 1, 2] = 2 * (y*z - r*x)
    R[:, 2, 0] = 2 * (x*z - r*y)
    R[:, 2, 1] = 2 * (y*z + r*x)
    R[:, 2, 2] = 1 - 2 * (x*x + y*y)
    return R

def build_rotation_inv(R):
    r  = np.zeros((R.shape[0], 4))
    r[:, 0] = np.sqrt(1+abs(R[:, 0, 0]+R[:, 1, 1]+R[:, 2, 2]))/2
    r[:, 1] = (R[:, 2, 1]-R[:, 1, 2])/(4*r[:, 0])
    r[:, 2] = (R[:, 0, 2]-R[:, 2, 0])/(4*r[:, 0])
    r[:, 3] = (R[:, 1, 0]-R[:, 0, 1])/(4*r[:, 0])

    return r

def rotate_point_cloud(batch_data):
    """ Randomly rotate the point clouds to augument the dataset
        rotation is per shape based along up direction
        Input:
          BxNx14 array, original batch of point clouds
        Return:
          BxNx14 array, rotated batch of point clouds
    """
    B, N, C = batch_data.shape
    for k in range(batch_data.shape[0]):
        rotation_angle = np.random.uniform() * 2 * np.pi
        cosval = np.cos(rotation_angle)
        sinval = np.sin(rotation_angle)
        rotation_matrix = np.array([[cosval, 0, sinval],
                                    [0, 1, 0],
                                    [-sinval, 0, cosval]])

        batch_data[k, :, :3] = (rotation_matrix@batch_data[k, :, :3].transpose(1,0)).transpose(1,0)
        
        if C >3 :
            transforms = build_rotation(batch_data[k, :, -4:])
            transforms = rotation_matrix @ transforms
            batch_data[k, :, -4:] = build_rotation_inv( transforms )

    return batch_data

def random_point_dropout(batch_pc, max_dropout_ratio=0.875):
    ''' batch_pc: BxNx14 '''
    for b in range(batch_pc.shape[0]):
        dropout_ratio =  np.random.random()*max_dropout_ratio # 0~0.875
        drop_idx = np.where(np.random.random((batch_pc.shape[1]))<=dropout_ratio)[0]
        if len(drop_idx)>0:
            batch_pc[b,drop_idx,:] = batch_pc[b,0,:] # set to the first point
    return batch_pc

def random_scale_point_cloud(batch_data, scale_low=0.8, scale_high=3):
    """ Randomly scale the point cloud. Scale is per point cloud.
        Input:
            BxNx14 array, original batch of point clouds
        Return:
            BxNx14 array, scaled batch of point clouds
    """
    B, N, C = batch_data.shape
    scales = np.random.uniform(scale_low, scale_high, B)
    for batch_index in range(B):
        batch_data[batch_index,:,:3] *= scales[batch_index]
        batch_data[batch_index,:,7:10] += np.log(scales[batch_index])
    return batch_data

def shift_point_cloud(batch_data, shift_range=0.1):
    """ Randomly shift point cloud. Shift is per point cloud.
        Input:
          BxNx14 array, original batch of point clouds
        Return:
          BxNx14 array, shifted batch of point clouds
    """
    B, N, C = batch_data.shape
    shifts = np.random.uniform(-shift_range, shift_range, (B,3))
    for batch_index in range(B):
        batch_data[batch_index,:,:3] += shifts[batch_index,:]
    return batch_data

def jitter_point_cloud(batch_data, sigma=0.01, clip=0.05):
    """ Randomly jitter points. jittering is per point.
        Input:
          BxNx14 array, original batch of point clouds
        Return:
          BxNx14 array, jittered batch of point clouds
    """
    B, N, C = batch_data.shape
    assert(clip > 0)
    jittered_data = np.clip(sigma * np.random.randn(B, N, C), -1*clip, clip)
    jittered_data += batch_data
    return jittered_data

def rotate_perturbation_point_cloud(batch_data, angle_sigma=0.06, angle_clip=0.18):
    """ Randomly perturb the point clouds by small rotations
        Input:
          BxNx14 array, original batch of point clouds
        Return:
          BxNx14 array, rotated batch of point clouds
    """
    B, N, C = batch_data.shape
    for k in range(batch_data.shape[0]):
        angles = np.clip(angle_sigma*np.random.randn(3), -angle_clip, angle_clip)
        Rx = np.array([[1,0,0],
                       [0,np.cos(angles[0]),-np.sin(angles[0])],
                       [0,np.sin(angles[0]),np.cos(angles[0])]])
        Ry = np.array([[np.cos(angles[1]),0,np.sin(angles[1])],
                       [0,1,0],
                       [-np.sin(angles[1]),0,np.cos(angles[1])]])
        Rz = np.array([[np.cos(angles[2]),-np.sin(angles[2]),0],
                       [np.sin(angles[2]),np.cos(angles[2]),0],
                       [0,0,1]])
        R = np.dot(Rz, np.dot(Ry,Rx))

        batch_data[k, :, :3] = (R @ batch_data[k, :, :3].transpose(1,0)).transpose(1,0)
        if C >3 :
            transforms = build_rotation(batch_data[k, :, -4:])
            transforms = R @ transforms
            batch_data[k, :, -4:] = build_rotation_inv( transforms )

    return batch_data


class BaseDataset(Dataset):

    def __init__(self,
        data_dir:str,
        data_split:str="file_paths.json",
        resolution:int=224,
        shuffle:bool=True,
        pc_prefix:str="point cloud of ",
        is_train:bool=True,
        using_channel:int=-1,
        load_extend=False,
        load_npy=False,
        load_features=False,
        clip_type = "eva_enormous",
        augment=False,
        turn_uni3d=False,
        preprocess_image=True,
        **kwargs
        ):

        super().__init__()
        self.data_dir = data_dir
        self.is_train = is_train

        self.pc_prefix = pc_prefix
        self.using_channel = using_channel
        self.augment = augment
        self.preprocess_image = preprocess_image
        
        content = self.read_file_paths(data_dir, data_split)

        try:
            if is_train: 
                self.file_paths = content["train"]
                if shuffle: random.shuffle(self.file_paths)
            else: 
                self.file_paths = content["test"]
        except:
            self.file_paths = []
        
        self.file_paths_copy = self.file_paths.copy()

        self.test_text = None
        self.load_npy = load_npy
        self.transform =  torchvision.transforms.Compose([
            torchvision.transforms.Resize((resolution,resolution), interpolation=torchvision.transforms.InterpolationMode.BICUBIC),
            torchvision.transforms.ToTensor(),
            torchvision.transforms.Normalize((0.48145466, 0.4578275, 0.40821073), (0.26862954, 0.26130258, 0.27577711)),
        ]) 
        self.load_extend = load_extend
        self.load_features = load_features
        self.text_type = "original"
        self.turn_uni3d = turn_uni3d

        features_root = "/data1/lihaoyuan/clip3D/clip3/data/features"
        self.features_root = os.path.join(features_root, clip_type)
    
    def dump_split_file(self, dump_file_paths, specific_keys=[], sample_num=10000, 
                        ratio=0.8, overlap=False, keep_original=True, keep_val_split=False):
        file_paths_json = os.path.join(self.data_dir, "file_paths.json")
        if keep_original:
            with open(file_paths_json, "r") as file:
                content = json.load(file)
                content["train"] = content["original"]["train"]
                if not keep_val_split: 
                    content["train"].extend(content["original"]["val"])
                content["test"] = content["original"]["test"]
                content.pop("original")
            file_paths_json = os.path.join(self.data_dir, dump_file_paths)
            with open(file_paths_json, "w") as file:
                json.dump(content, file, indent=4)
            exit()
        else:

            with open(file_paths_json, "r") as file:
                content = json.load(file)
                content["train"] = []
                content["test"] = []
                content.pop("original")
            
            for key in content["all"].keys():
                item_type_paths = content["all"][key]
                random.shuffle(item_type_paths)
                item_type_paths = item_type_paths[:sample_num]

                if key not in specific_keys:
                    content["train"].extend(item_type_paths)
                    continue

                train_test_ptr = int(len(item_type_paths)*ratio)

                if overlap:
                    content["train"].extend(item_type_paths)
                    content["test"].extend(item_type_paths[train_test_ptr:])
                else:
                    content["train"].extend(item_type_paths[:train_test_ptr])
                    content["test"].extend(item_type_paths[train_test_ptr:])
            
            content.pop("all")
            file_paths_json = os.path.join(self.data_dir, dump_file_paths)
            with open(file_paths_json, "w") as file:
                json.dump(content, file, indent=4)
            
            exit()

    def read_file_paths(self, data_dir, data_split="file_paths.json"):
        file_paths_json = os.path.join(data_dir, data_split)
        with open(file_paths_json, "r") as file:
            content = json.load(file)
        return content

    def expand_3dgs(self, guassians, clip_num=1024):
        '''
        3dgs : [n, 14]
        '''
        pts_num = guassians.shape[0]
        if pts_num == clip_num:
            return guassians
        elif pts_num<clip_num: 
            guassians = guassians.repeat( int(clip_num/pts_num)+1 ,1)
            return guassians[:clip_num]
        else:
            data_index = np.arange(pts_num)
            random.shuffle(data_index)
            guassians = guassians[data_index[:clip_num]]
            return guassians

    ### Read image ###
    def _get_objaverse_image_(self, pkl_data):
        exist_img_names = os.listdir(pkl_data["img"])
        img_names = []
        for img_name in exist_img_names:
            if "npy" not in img_name and os.path.isfile(os.path.join(pkl_data["img"],img_name)): 
                img_names.append(img_name)
        img_path = os.path.join(pkl_data["img"], img_names[np.random.randint(len(img_names))])
        image = Image.open(img_path).convert("RGB")
        return image

    def _get_sunrgbd_image_(self, pkl_data):
        image = Image.fromarray(pkl_data["img"])
        return image

    def _get_abo_image_(self, pkl_data):
        exist_img_names = os.listdir(pkl_data["img"])
        img_names = []
        for img_name in exist_img_names:
            if "json" not in img_name: img_names.append(img_name)
        img_path = os.path.join(pkl_data["img"], img_names[np.random.randint(len(img_names))])
        image = Image.open(img_path).convert("RGB")
        return image

    def _get_mvimgnet_image_(self, pkl_data):
        exist_img_names = os.listdir(pkl_data["img"])
        img_names = []
        for img_name in exist_img_names:
            if "bg_removed" not in img_name: img_names.append(img_name)
        img_path = os.path.join(pkl_data["img"], img_names[np.random.randint(len(img_names))])
        image = Image.open(img_path).convert("RGB")
        return image

    def _getitem_image_(self, pkl_data):
        if "dataset" in pkl_data.keys(): 
            dataset_caption_func = {
                "sunrgbd": self._get_sunrgbd_image_,
                "abo": self._get_abo_image_,
                "objaverse": self._get_objaverse_image_,
                "mvimgnet": self._get_mvimgnet_image_,
            }
            image = dataset_caption_func[pkl_data['dataset']](pkl_data)
        else:
            image = Image.fromarray(pkl_data["img"])
        
        if self.preprocess_image: image = self.transform(image)
        else: image = np.array(image)

        return image
        
    ### Read caption ###
    def _get_objaverse_caption_(self, pkl_data):
        if "human_prompt" in pkl_data.keys():
            text = self.pc_prefix + pkl_data["human_prompt"][0]
        elif "machine_prompt" in pkl_data.keys():
            text = self.pc_prefix + pkl_data["machine_prompt"]
        else:
            text = self.pc_prefix + pkl_data["label"]
        return text

    def _get_sunrgbd_caption_(self, pkl_data):
        return self.pc_prefix + pkl_data["label"]

    def _get_abo_caption_(self, pkl_data):
        text = self.pc_prefix + pkl_data["machine_prompt"][0]
        text = text[:310]
        text = " ".join(text.split(" ")[:50])
        return text

    def _get_mvimgnet_caption_(self, pkl_data):
        return self.pc_prefix + pkl_data["label"]

    def _getitem_caption_(self, pkl_data):
        if "dataset" in pkl_data.keys(): 
            dataset_caption_func = {
                "sunrgbd": self._get_sunrgbd_caption_,
                "abo": self._get_abo_caption_,
                "objaverse": self._get_objaverse_caption_,
                "mvimgnet": self._get_mvimgnet_caption_,
            }
            text = dataset_caption_func[pkl_data['dataset']](pkl_data)
        else:
            text = self.pc_prefix + pkl_data["label"]
        text = text[:320]
        return text


    def __get_base_turn__(self, gaussians):
        x, y, z = gaussians[:, 0].copy(), gaussians[:, 1].copy(), gaussians[:, 2].copy()
        gaussians[:, 0] = -x
        gaussians[:, 1] = z
        gaussians[:, 2] = y
        return gaussians
    
    def __get_default_turn__(self, gaussians):
        return gaussians
    

    def change_to_uni3d(self, pkl_gaussians, pkl_data):
        if "dataset" in pkl_data.keys(): 
            dataset_turn_func = {
                "sunrgbd": self.__get_default_turn__,
                "abo": self.__get_base_turn__,
                "objaverse": self.__get_base_turn__,
                "mvimgnet": self.__get_default_turn__,
            }
            pkl_gaussians = dataset_turn_func[pkl_data['dataset']](pkl_gaussians)
        else:
            pkl_gaussians = self.__get_base_turn__(pkl_gaussians)
        return pkl_gaussians
    
    def _getitem_3dgs_(self, pkl_data):
        #  51407 | 139282, R:[-1.92, -1.70, 0.25, 1.92, 6.35], G:[-1.92, -1.71, 0.14, 1.78, 6.50], B:[-1.92, -1.73, 0.02, 1.73, 6.31]

        if self.load_npy:
            item_id = pkl_data["name"]
            npy_path = self.item_id_to_pts[item_id]
            xyz = np.load(npy_path, allow_pickle=True)
            if self.augment and self.is_train: 
                xyz = self.gaussian_augment(xyz)
            pkl_gaussians = np.concatenate((xyz, np.ones((xyz.shape[0], 11))*0.4), -1)

            ran_sel = np.random.randint(0, pkl_gaussians.shape[0], 1_024)
            pkl_gaussians = pkl_gaussians[ran_sel]
        
        else:
            pkl_gaussians = self.expand_3dgs(pkl_data["3dgs"])
            if self.augment and self.is_train: 
                pkl_gaussians = self.gaussian_augment(pkl_gaussians)
            pkl_gaussians[:,3:] = np.tanh(pkl_gaussians[:,3:])

            if self.using_channel>0:
                pkl_gaussians = pkl_gaussians[:,:self.using_channel]
        
        if self.turn_uni3d: pkl_gaussians = self.change_to_uni3d(pkl_gaussians, pkl_data)
        pkl_gaussians = torch.from_numpy(pkl_gaussians).to(torch.float32)

        return pkl_gaussians.transpose(0,1)

    ### extra ###
    def _getitem_extra_(self, pkl_data, meta_data):
        return meta_data

    def gaussian_augment(self, gaussians):
        gaussians = gaussians[None, ...]
        gaussians = random_point_dropout(gaussians)
        gaussians = random_scale_point_cloud(gaussians)
        gaussians = shift_point_cloud(gaussians)
        gaussians = rotate_perturbation_point_cloud(gaussians)
        gaussians = rotate_point_cloud(gaussians)
        gaussians = jitter_point_cloud(gaussians)

        return gaussians[0]

    def gaussian_random_augment(self, gaussians):
        gaussians = gaussians[None, ...]
        augment_func_list = [random_point_dropout, random_scale_point_cloud, shift_point_cloud,
                jitter_point_cloud, rotate_perturbation_point_cloud, rotate_point_cloud]
        augment_func = np.random.choice(augment_func_list,p=[1/len(augment_func_list)]*len(augment_func_list))
        gaussians = augment_func(gaussians)

        return gaussians[0]

    def __getitem__(self, index):
        '''
        name:                           <numpy.str_>
        img:            [325, 115, 3]   <numpy.ndarray>
        className2D:                    <numpy.str_>
        3dgs:           [13277, 14]     <numpy.ndarray>
        className3D:                    <numpy.str_> (old [1, ] | new [])
        '''
        pkl_path = self.file_paths[index]
        # pkl_path = "/data1/lihaoyuan/clip3D/gaussian-splatting/clip3/0a0a8a932906419ca895e31401fa16ea.pkl"

        pkl_data = torch.load(pkl_path)
        meta_data = {}

        meta_data["gaussian"] = self._getitem_3dgs_(pkl_data)

        if self.load_features and self.is_train:
            item_path = pkl_data["item_path"].split("objects/")[1].split(".")[0]+".npy"
            meta_data["image"] = torch.from_numpy(np.load(os.path.join(self.features_root, pkl_data["dataset"], "image_features", item_path)))
            meta_data["text"] = torch.from_numpy(np.load(os.path.join(self.features_root, pkl_data["dataset"], "text_features", self.text_type, item_path)))
        else:
            meta_data["image"] = self._getitem_image_(pkl_data)
            meta_data["text"] = self._getitem_caption_(pkl_data)

        meta_data["item_path"] = pkl_data["item_path"]

        meta_data = self._getitem_extra_(pkl_data, meta_data)

        return meta_data

    def __len__(self):
        return len(self.file_paths)

