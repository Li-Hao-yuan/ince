import os
import torch
import torch.nn as nn
import numpy as np
from plyfile import PlyData, PlyElement
from get_model import CLIP3

device = torch.device("cuda:1")

def load_ply(path, max_sh_degree=0):
    plydata = PlyData.read(path)

    xyz = np.stack((np.asarray(plydata.elements[0]["x"]),
                    np.asarray(plydata.elements[0]["y"]),
                    np.asarray(plydata.elements[0]["z"])),  axis=1)
    opacities = np.asarray(plydata.elements[0]["opacity"])[..., np.newaxis]

    features_dc = np.zeros((xyz.shape[0], 3, 1))
    features_dc[:, 0, 0] = np.asarray(plydata.elements[0]["f_dc_0"])
    features_dc[:, 1, 0] = np.asarray(plydata.elements[0]["f_dc_1"])
    features_dc[:, 2, 0] = np.asarray(plydata.elements[0]["f_dc_2"])

    extra_f_names = [p.name for p in plydata.elements[0].properties if p.name.startswith("f_rest_")]
    extra_f_names = sorted(extra_f_names, key = lambda x: int(x.split('_')[-1]))
    assert len(extra_f_names)==3*(max_sh_degree + 1) ** 2 - 3
    features_extra = np.zeros((xyz.shape[0], len(extra_f_names)))
    for idx, attr_name in enumerate(extra_f_names):
        features_extra[:, idx] = np.asarray(plydata.elements[0][attr_name])
    # Reshape (P,F*SH_coeffs) to (P, F, SH_coeffs except DC)
    features_extra = features_extra.reshape((features_extra.shape[0], 3, (max_sh_degree + 1) ** 2 - 1))

    scale_names = [p.name for p in plydata.elements[0].properties if p.name.startswith("scale_")]
    scale_names = sorted(scale_names, key = lambda x: int(x.split('_')[-1]))
    scales = np.zeros((xyz.shape[0], len(scale_names)))
    for idx, attr_name in enumerate(scale_names):
        scales[:, idx] = np.asarray(plydata.elements[0][attr_name])

    rot_names = [p.name for p in plydata.elements[0].properties if p.name.startswith("rot")]
    rot_names = sorted(rot_names, key = lambda x: int(x.split('_')[-1]))
    rots = np.zeros((xyz.shape[0], len(rot_names)))
    for idx, attr_name in enumerate(rot_names):
        rots[:, idx] = np.asarray(plydata.elements[0][attr_name])

    # _xyz: [1024,3]
    # _features_dc: [1024,1,3]
    # _features_rest: [1024,15,sh_dgree]
    # _opacity: [1024,1]
    # _scaling: [1024,3]
    # _rotation: [1024,4]

    _xyz = torch.tensor(xyz, dtype=torch.float)
    num_pts = _xyz.shape[0]
    _features_dc = torch.tensor(features_dc, dtype=torch.float).transpose(1, 2).contiguous().reshape(num_pts, -1) # 3,1 -> 1,3 -> 3
    _features_rest = torch.tensor(features_extra, dtype=torch.float).transpose(1, 2).contiguous().reshape(num_pts, -1)
    _opacity = torch.tensor(opacities, dtype=torch.float)
    _scaling = torch.tensor(scales, dtype=torch.float)
    _rotation = torch.tensor(rots, dtype=torch.float)

    pts_feature = torch.cat(
        (_xyz, _features_dc, _features_rest, _opacity, _scaling, _rotation), dim=1
    )

    return pts_feature

def save_ply(data, save_path):

    # _xyz: [1024,3]
    # _features_dc: [1024,1,3]
    # _features_rest: [1024,15,3]
    # _opacity: [1024,1]
    # _scaling: [1024,3]
    # _rotation: [1024,4]

    def construct_list_of_attributes():
        l = ['x', 'y', 'z', 'nx', 'ny', 'nz']
        # All channels except the 3 DC
        for i in range(3):
            l.append('f_dc_{}'.format(i))
        # for i in range(45):
        #     l.append('f_rest_{}'.format(i))
        l.append('opacity')
        for i in range(3):
            l.append('scale_{}'.format(i))
        for i in range(4):
            l.append('rot_{}'.format(i))
        return l
    
    xyz = data[:,:3].data.numpy()
    f_dc = data[:,3:6].reshape((-1,1,3)).transpose(1, 2).flatten(start_dim=1).data.numpy() # 1,3 -> 3,1 -> 3
    opacities = data[:,6:7].data.numpy()
    scale = data[:,7:10].data.numpy()
    rotation = data[:,10:14].data.numpy()
    normals = np.zeros_like(xyz)

    dtype_full = [(attribute, 'f4') for attribute in construct_list_of_attributes()]
    elements = np.empty(xyz.shape[0], dtype=dtype_full)
    attributes = np.concatenate((xyz, normals, f_dc, opacities, scale, rotation), axis=1)
    elements[:] = list(map(tuple, attributes))
    el = PlyElement.describe(elements, 'vertex')
    PlyData([el]).write(save_path)

def get_model():
    clip3 = CLIP3(
        clip_model='/data1/lihaoyuan/clip3D/clip3/cache/ViT-B-16.pt',
        pointnet_model='uni3D',
        learning_rate=1e-4,
        pts_channel=14,
        forward_all=True,
        model_setting=dict(
            load_features=True,
            pc_model='eva02_small_patch14_224',
            pretrained_pc=None,
            drop_path_rate=0.2,
            pc_feat_dim=384,
            embed_dim=1024,
            group_size=64,
            num_group=512,
            output_dim=1024,
            pc_encoder_dim=512,
            patch_dropout=0.5,
            in_channel=6,
            model_type='parallel',
            load_rgb=False,
            load_pretrained=True,
            ckpt_path='/data1/lihaoyuan/clip3D/clip3/cache/uni3d-S.pt'),
    )
    ckpt_path = "/data1/lihaoyuan/clip3D/clip3/work_dirs/encoder/objaverse_1024/model_epoch15.pth"
    clip3.pointnet.load_state_dict(torch.load(ckpt_path, map_location="cpu"))
    clip3 = clip3.to(device)

    return clip3

def get_clip3_encoded_features():
    clip3 = get_model()

    gaussian = torch.load(pkl_path, map_location="cpu")["3dgs"]
    gaussian[:,3:] = np.tanh(gaussian[:,3:])
    gaussian = torch.from_numpy(gaussian).transpose(1,0).unsqueeze(0)
    gaussian = gaussian.to(device)

    gaussian_features, _ = clip3.encode_gaussian(gaussian)
    return gaussian_features[0]

def sort_gaussian(gaussian):
    z = gaussian[:,2].sort()[1]
    gaussian = gaussian[z]

    y = gaussian[:,1].sort()[1]
    gaussian = gaussian[y]

    x = gaussian[:,0].sort()[1]
    gaussian = gaussian[x]

    return gaussian


# item_list = ["0a0a8a932906419ca895e31401fa16ea"]
item_list = ["00ce9c02f0b84cba9ac283f555815b6f","00fa1623636640d7a21e5a465de4e496","0b7a6421ef3a4c22afbe6b634f4afd0a", "0ee9c78f195a40c2b971b3ec524fc6c3",
"00f665c4abc04d48bdcb430131bc5b73","0c8ddff67c5e4af3a3ae39547774054d", "0f6783aee8ed46099a4bb6250fb8ff5f",
"00f9d4e6a3ca47239ef1ea653cf7f821","0af71faac3984fb68be0bb3b9b0f420a","0c914465dcfa455b8cff170c6ed75d47"]

only_xyz = False
use_mlp = False
use_trans = True

gaussian_features_list, gt_list = [], []
for item_id in item_list:
    pkl_path = "/data1/lihaoyuan/clip3D/gaussian-splatting/clip3/objaverse_human/objects/"+item_id+".pkl"

    # gaussian_features = get_clip3_encoded_features().cpu().data.numpy()
    # print("gaussian_features", gaussian_features.shape)
    # np.save("/data1/lihaoyuan/clip3D/gaussian-splatting/output/test/"+item_id+"/point_cloud/iteration_3000/gaussian_features.npy", gaussian_features)
    # continue

    gaussian_features_path = "/data1/lihaoyuan/clip3D/gaussian-splatting/output/test/"+item_id+"/point_cloud/iteration_3000/gaussian_features.npy"
    gaussian_features = torch.from_numpy(np.load(gaussian_features_path)).unsqueeze(0).unsqueeze(0)
    gaussian_features_list.append(gaussian_features)

    gt = torch.load(pkl_path)["3dgs"]
    gt[:,3:] = np.tanh(gt[:,3:])
    gt = sort_gaussian(torch.from_numpy(gt)).transpose(1,0).unsqueeze(0)

    if only_xyz: gt = gt[:,:3]
    gt_list.append(gt)

gaussian_features = torch.cat(gaussian_features_list)
gt = torch.cat(gt_list)
print()

print("#"*40)
print("input:", gaussian_features.shape, " | gt:", gt.shape)
print("#"*40, end="\n\n")

if only_xyz:
    if use_mlp: decoder = nn.Linear(1024, 1024*3).to(device)
    else: decoder = nn.Conv1d(1, 3, 3, 1, 1).to(device)
else:
    if use_mlp: decoder = nn.Linear(1024, 1024*14).to(device)
    else: decoder = nn.Conv1d(14, 14, 3, 1, 1).to(device)


if only_xyz:
    if use_mlp: lr = 1e-5 # ok
    else: lr = 1e-1
else:
    if use_mlp: lr = 1e-4
    else: lr = 1e-2

optimizer = torch.optim.AdamW(decoder.parameters(), lr=lr)
l1_loss = torch.nn.L1Loss().to(device)
l2_loss = torch.nn.MSELoss().to(device)

gaussian_features, gt = gaussian_features.to(device), gt.to(device)

# 100
EPOCH = 3000
for epoch in range(EPOCH):
    output = decoder(gaussian_features)
    if use_mlp: output = output.view(len(item_list), -1, 1024)

    loss = l1_loss(output, gt)# + l2_loss(output, gt)

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    print("Epoch: [%d] | loss: %.8f"%(epoch, loss.item()))
    

output = decoder(gaussian_features)
if use_mlp: output = output.view(len(item_list), -1, 1024)
output = output.transpose(2,1).cpu()
if only_xyz: output = torch.concatenate((output, torch.zeros((1024,11))),axis=-1)

output[:,:,3:] = torch.arctanh(output[:,:,3:].clamp(-1+1e-8, 1-1e-8))

for i,item_id in enumerate(item_list):
    save_ply(output[i], "/data1/lihaoyuan/clip3D/gaussian-splatting/output/test/"+item_id+"/point_cloud/iteration_3000/point_cloud.ply")


# CUDA_VISIBLE_DEVICES=1 python render.py -m output/test/00fa1623636640d7a21e5a465de4e496


