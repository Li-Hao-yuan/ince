import open_clip

clip_model, _, _ = open_clip.create_model_and_transforms(model_name="EVA02-B-16", pretrained="/data1/lihaoyuan/clip3D/clip3/cache/laion/CLIP-ViT-bigG-14-laion2B-39B-b160k/pytorch_model.bin") 